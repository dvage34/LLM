# Mini LLM pour NumWorks

Un petit modèle de langage **au niveau des caractères** (réseau de neurones à une couche cachée,
contexte de 8 lettres, ~15 000 paramètres en int8 ≈ 15 Ko) qui génère du texte directement sur la calculatrice.
Ce n'est pas un transformer : c'est la version minuscule du même principe (prédire la lettre suivante).

## Contenu

| Fichier | Rôle |
|---|---|
| `corpus.txt` | Texte d'entraînement (remplace-le par le tien) |
| `train.py` | Entraîne le modèle (numpy) et écrit `src/model.h` |
| `src/lm.h` | Moteur d'inférence en C pur (sans libm ni malloc) |
| `src/main.c` | Application NumWorks (affichage + touches) |
| `src/model.h` | Poids générés |
| `test/` | Faux `eadk.h` + test sur PC |

## Compiler en `.nwa` sans rien installer (GitHub Actions)

1. Crée un dépôt GitHub (gratuit) et envoie-y tout ce dossier (y compris `.github/`).
2. Onglet **Actions** > **build-nwa** > **Run workflow**.
3. Une fois terminé, télécharge l'artefact **minillm-nwa** : il contient `app.nwa`.
4. Envoie-le sur https://my.numworks.com/apps.

(Workflow non testé : si l'étape *Compiler* échoue, copie le message d'erreur et je corrige.)

## Compiler en local

Il faut la chaîne de compilation NumWorks, que je n'ai pas pu utiliser ici (pas de réseau).

```bash
# Debian/Ubuntu
sudo apt install git make gcc-arm-none-eabi npm

git clone https://github.com/numworks/epsilon-sample-app-c
cd epsilon-sample-app-c
# copie lm.h, main.c et model.h par-dessus le dossier src/ du gabarit
cp /chemin/vers/minillm/src/{main.c,lm.h,model.h} src/
make            # produit output/app.nwa
```

Puis envoie `output/app.nwa` sur https://my.numworks.com/apps (calculatrice branchée en USB).
`make run` compile et installe directement.

Si le build échoue avec `eadk.h: No such file or directory` (Node trop récent), dans le `Makefile` du gabarit :
`NWLINK = npx --yes -- nwlink@0.0.19` et remplace `eadk-cflags` par `eadk-cflags-device`.

## Utilisation

- **OK** (maintenu) : génère la suite du texte
- **Haut / Bas** : température (basse = prudent, haute = créatif)
- **Gauche** : change d'amorce de phrase
- **Retour** : efface et recommence
- **Home** : quitte

## Réentraîner avec ton propre texte

```bash
python3 train.py mon_texte.txt --epochs 60   # écrit src/model.h
```

Plus le texte est long (plusieurs dizaines de Ko), meilleurs sont les résultats. Pour un modèle plus gros,
modifie `N`, `E`, `H` en haut de `train.py` (le modèle doit rester sous quelques dizaines de Ko pour
tenir dans la mémoire des apps externes).

## Test sur PC

```bash
gcc -O2 -o host_test test/host_test.c && ./host_test
gcc -Itest -Isrc -fsyntax-only src/main.c   # vérifie que main.c compile
```
