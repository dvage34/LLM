#!/usr/bin/env python3
"""Entraîne un mini modèle de langage au niveau des caractères (MLP façon Bengio)
et l'exporte en int8 dans src/model.h pour la calculatrice NumWorks.

Usage: python3 train.py [corpus.txt] [--epochs 60]
Dépendance : numpy uniquement.
"""
import sys, re, unicodedata, argparse
import numpy as np

ALPHABET = " abcdefghijklmnopqrstuvwxyz.,'?-"   # 32 symboles, 5 bits
V = len(ALPHABET)
N = 8      # longueur du contexte (lettres lues)
E = 10     # dimension des embeddings
H = 128    # neurones cachés
IDX = {c: i for i, c in enumerate(ALPHABET)}


def normalize(text):
    text = unicodedata.normalize("NFKD", text.lower())
    text = "".join(c for c in text if not unicodedata.combining(c))
    text = text.replace("’", "'").replace("œ", "oe")
    text = re.sub(r"[;:!]", ".", text)
    text = "".join(c if c in IDX else " " for c in text)
    return re.sub(r" +", " ", text).strip()


def softsign(x):
    return x / (1.0 + np.abs(x))


def softsign_grad(x):
    return 1.0 / (1.0 + np.abs(x)) ** 2


def build_dataset(ids):
    # on ajoute N espaces au début pour pouvoir prédire dès la première lettre
    ids = np.concatenate([np.zeros(N, dtype=np.int64), ids])
    X = np.stack([ids[i:i + N] for i in range(len(ids) - N)])
    Y = ids[N:]
    return X, Y


def forward(P, X):
    emb = P["emb"][X].reshape(len(X), N * E)
    z1 = emb @ P["w1"] + P["b1"]
    h = softsign(z1)
    logits = h @ P["w2"] + P["b2"]
    return emb, z1, h, logits


def loss_and_grads(P, X, Y):
    emb, z1, h, logits = forward(P, X)
    logits = logits - logits.max(1, keepdims=True)
    p = np.exp(logits)
    p /= p.sum(1, keepdims=True)
    B = len(X)
    loss = -np.log(p[np.arange(B), Y] + 1e-9).mean()
    d = p
    d[np.arange(B), Y] -= 1
    d /= B
    g = {}
    g["w2"] = h.T @ d
    g["b2"] = d.sum(0)
    dh = d @ P["w2"].T
    dz1 = dh * softsign_grad(z1)
    g["w1"] = emb.T @ dz1
    g["b1"] = dz1.sum(0)
    demb = (dz1 @ P["w1"].T).reshape(B, N, E)
    g["emb"] = np.zeros_like(P["emb"])
    np.add.at(g["emb"], X, demb)
    return loss, g


def quantize(w):
    scale = float(np.abs(w).max()) / 127.0
    q = np.clip(np.round(w / scale), -127, 127).astype(np.int8)
    return q, scale


def dequantized_params(P):
    Q = {}
    for k in ("emb", "w1", "w2"):
        q, s = quantize(P[k])
        Q[k] = q.astype(np.float32) * s
    Q["b1"], Q["b2"] = P["b1"], P["b2"]
    return Q


def c_array(name, arr, ctype, per_line=16):
    flat = arr.flatten()
    lines = []
    for i in range(0, len(flat), per_line):
        chunk = flat[i:i + per_line]
        if ctype == "float":
            lines.append("  " + ", ".join(f"{v:.6e}f" for v in chunk) + ",")
        else:
            lines.append("  " + ", ".join(str(int(v)) for v in chunk) + ",")
    return f"static const {ctype} {name}[{len(flat)}] = {{\n" + "\n".join(lines) + "\n};\n"


def export_header(P, path):
    out = ["/* Fichier généré par train.py : ne pas modifier à la main. */",
           "#ifndef MODEL_H", "#define MODEL_H", "#include <stdint.h>", "",
           f'#define LM_V {V}', f'#define LM_N {N}', f'#define LM_E {E}', f'#define LM_H {H}',
           f'#define LM_ALPHABET "{ALPHABET}"', ""]
    for k in ("emb", "w1", "w2"):
        q, s = quantize(P[k])
        out.append(f"#define LM_S_{k.upper()} {s:.8e}f")
        out.append(c_array(f"lm_{k}", q, "int8_t"))
    out.append(c_array("lm_b1", P["b1"].astype(np.float32), "float"))
    out.append(c_array("lm_b2", P["b2"].astype(np.float32), "float"))
    out.append("#endif")
    with open(path, "w") as f:
        f.write("\n".join(out))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("corpus", nargs="?", default="corpus.txt")
    ap.add_argument("--epochs", type=int, default=60)
    ap.add_argument("--out", default="src/model.h")
    args = ap.parse_args()

    text = normalize(open(args.corpus, encoding="utf-8").read())
    ids = np.array([IDX[c] for c in text], dtype=np.int64)
    X, Y = build_dataset(ids)
    print(f"corpus: {len(text)} caractères, {len(X)} exemples")

    rng = np.random.default_rng(1234)
    P = {
        "emb": rng.normal(0, 0.5, (V, E)),
        "w1": rng.normal(0, 1 / np.sqrt(N * E), (N * E, H)),
        "b1": np.zeros(H),
        "w2": rng.normal(0, 1 / np.sqrt(H), (H, V)),
        "b2": np.zeros(V),
    }
    n_params = sum(v.size for v in P.values())
    print(f"paramètres: {n_params} (≈ {n_params / 1024:.1f} Ko en int8)")

    m = {k: np.zeros_like(v) for k, v in P.items()}
    s = {k: np.zeros_like(v) for k, v in P.items()}
    lr, b1, b2, t = 3e-3, 0.9, 0.999, 0
    B = 256
    for ep in range(1, args.epochs + 1):
        perm = rng.permutation(len(X))
        tot = 0.0
        for i in range(0, len(X), B):
            idx = perm[i:i + B]
            loss, g = loss_and_grads(P, X[idx], Y[idx])
            t += 1
            for k in P:
                m[k] = b1 * m[k] + (1 - b1) * g[k]
                s[k] = b2 * s[k] + (1 - b2) * g[k] ** 2
                mh = m[k] / (1 - b1 ** t)
                sh = s[k] / (1 - b2 ** t)
                P[k] -= lr * (0.5 * (1 + np.cos(np.pi * ep / args.epochs))) * mh / (np.sqrt(sh) + 1e-8)
            tot += loss * len(idx)
        if ep % 10 == 0 or ep == 1:
            print(f"époque {ep:3d}  perte {tot / len(X):.3f}")

    Q = dequantized_params(P)
    lf = loss_and_grads(P, X, Y)[0]
    lq = loss_and_grads(Q, X, Y)[0]
    print(f"perte float {lf:.3f} -> après quantification int8 {lq:.3f}")
    export_header(P, args.out)
    print(f"modèle écrit dans {args.out}")


if __name__ == "__main__":
    main()
