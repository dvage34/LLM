/* Mini LLM pour NumWorks : génération de texte caractère par caractère.
 *
 * Touches :
 *   OK        générer la suite du texte (maintenu : génération continue)
 *   Haut/Bas  température +/- (plus haute = plus créatif, plus basse = plus sage)
 *   Gauche    changer d'amorce de phrase
 *   Retour    effacer l'écran et recommencer
 *   Home      quitter (géré par le système)
 */
#include "eadk.h"
#include "lm.h"

#define COLS 44
#define ROWS 18
#define LINE_H 12
#define TOP 24

static const char *const kSeeds[] = {
  "Bonjour, ", "Un nombre ", "Le chat ", "Il fait ", "La calculatrice ", "Je suis ",
};
#define NSEEDS ((int)(sizeof(kSeeds) / sizeof(kSeeds[0])))

static char gScreen[ROWS][COLS + 1];
static int gRow, gCol;

static void screen_clear(void) {
  for (int r = 0; r < ROWS; r++) {
    for (int c = 0; c < COLS; c++) gScreen[r][c] = ' ';
    gScreen[r][COLS] = 0;
  }
  gRow = gCol = 0;
}

static void screen_putc(char ch) {
  if (gCol >= COLS) { gRow++; gCol = 0; }
  if (gRow >= ROWS) {           /* défilement d'une ligne vers le haut */
    for (int r = 1; r < ROWS; r++)
      for (int c = 0; c <= COLS; c++) gScreen[r - 1][c] = gScreen[r][c];
    for (int c = 0; c < COLS; c++) gScreen[ROWS - 1][c] = ' ';
    gRow = ROWS - 1;
  }
  gScreen[gRow][gCol++] = ch;
}

static void draw_all(float temperature) {
  const eadk_color_t white = 0xFFFF, black = 0x0000, grey = 0x7BEF, blue = 0x04DF;
  eadk_display_push_rect_uniform(eadk_screen_rect, white);
  eadk_display_push_rect_uniform((eadk_rect_t){0, 0, 320, 18}, blue);
  eadk_display_draw_string("Mini LLM", (eadk_point_t){4, 3}, false, white, blue);

  /* affiche la température avec une décimale, sans printf */
  char t[24] = "temp. x.x  (haut/bas)";
  int tt = (int)(temperature * 10.0f + 0.5f);
  t[6] = (char)('0' + tt / 10);
  t[8] = (char)('0' + tt % 10);
  eadk_display_draw_string(t, (eadk_point_t){120, 3}, false, white, blue);

  for (int r = 0; r < ROWS; r++) {
    char first = gScreen[r][0];
    (void)first;
    eadk_display_draw_string(gScreen[r], (eadk_point_t){4, (uint16_t)(TOP + r * LINE_H)},
                             false, black, white);
  }
  eadk_display_draw_string("OK: generer  <: amorce  Retour: effacer", (eadk_point_t){4, 226},
                           false, grey, white);
}

static void start_text(lm_state_t *lm, int seedIndex) {
  screen_clear();
  for (int k = 0; k < LM_N; k++) lm->ctx[k] = 0;
  for (const char *p = kSeeds[seedIndex]; *p; p++) {
    lm_feed(lm, *p);
    screen_putc(*p);
  }
}

static void generate(lm_state_t *lm, int count, float temperature) {
  const char *alpha = LM_ALPHABET;
  for (int i = 0; i < count; i++) {
    int v = lm_sample(lm, temperature, 8);
    screen_putc(alpha[v]);
  }
}

int main(int argc, char *argv[]) {
  (void)argc; (void)argv;
  lm_state_t lm;
  lm_init(&lm, 0x1234ABCDu ^ eadk_random());

  float temperature = 0.8f;
  int seedIndex = 0;
  start_text(&lm, seedIndex);
  generate(&lm, 120, temperature);
  draw_all(temperature);

  eadk_keyboard_state_t prev = 0;
  uint32_t ticks = 0;
  while (true) {
    eadk_keyboard_state_t k = eadk_keyboard_scan();
    ticks++;
    bool changed = false;
    bool pressed_up = eadk_keyboard_key_down(k, eadk_key_up) && !eadk_keyboard_key_down(prev, eadk_key_up);
    bool pressed_down = eadk_keyboard_key_down(k, eadk_key_down) && !eadk_keyboard_key_down(prev, eadk_key_down);
    bool pressed_left = eadk_keyboard_key_down(k, eadk_key_left) && !eadk_keyboard_key_down(prev, eadk_key_left);
    bool pressed_back = eadk_keyboard_key_down(k, eadk_key_back) && !eadk_keyboard_key_down(prev, eadk_key_back);

    if (eadk_keyboard_key_down(k, eadk_key_ok)) {
      lm.rng ^= ticks * 2654435761u;       /* un peu d'entropie supplémentaire */
      generate(&lm, 40, temperature);
      changed = true;
    }
    if (pressed_up && temperature < 1.6f) { temperature += 0.1f; changed = true; }
    if (pressed_down && temperature > 0.21f) { temperature -= 0.1f; changed = true; }
    if (pressed_left) {
      seedIndex = (seedIndex + 1) % NSEEDS;
      start_text(&lm, seedIndex);
      generate(&lm, 60, temperature);
      changed = true;
    }
    if (pressed_back) {
      start_text(&lm, seedIndex);
      changed = true;
    }
    if (changed) draw_all(temperature);
    prev = k;
    eadk_timing_msleep(30);
  }
  return 0;
}
