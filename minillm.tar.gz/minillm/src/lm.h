/* Moteur d'inférence du mini modèle de langage.
 * C pur : pas de libm, pas de malloc, indépendant de la plateforme. */
#ifndef LM_ENGINE_H
#define LM_ENGINE_H

#include <stdint.h>
#include "model.h"

typedef struct {
  uint8_t ctx[LM_N];   /* derniers symboles lus (le plus ancien en premier) */
  uint32_t rng;        /* état du générateur pseudo-aléatoire xorshift32 */
} lm_state_t;

static uint32_t lm_rand(lm_state_t *s) {
  uint32_t x = s->rng;
  x ^= x << 13; x ^= x >> 17; x ^= x << 5;
  s->rng = x;
  return x;
}

/* Exponentielle rapide pour x <= 0 (suffisant pour un softmax stabilisé). */
static float lm_exp_neg(float x) {
  if (x < -16.0f) return 0.0f;
  /* e^x = 2^(x*log2(e)) ; 2^i * 2^f avec f dans [0,1) */
  float t = x * 1.4426950409f;
  int i = (int)t;
  if ((float)i > t) i--;        /* floor */
  float f = t - (float)i;
  /* 2^f ~ polynôme de degré 4 (erreur < 1e-4 sur [0,1]) */
  float p = 1.0f + f * (0.6931472f + f * (0.2402265f + f * (0.0555041f + f * 0.0096181f)));
  while (i < 0 && p > 1e-30f) { p *= 0.5f; i++; }
  return p;
}

static inline float lm_softsign(float x) {
  return x / (1.0f + (x < 0 ? -x : x));
}

/* Calcule les logits des V symboles suivants à partir du contexte. */
static void lm_logits(const lm_state_t *s, float *logits) {
  float x[LM_N * LM_E];
  float h[LM_H];
  for (int k = 0; k < LM_N; k++) {
    const int8_t *e = &lm_emb[s->ctx[k] * LM_E];
    for (int d = 0; d < LM_E; d++) x[k * LM_E + d] = (float)e[d] * LM_S_EMB;
  }
  for (int j = 0; j < LM_H; j++) h[j] = lm_b1[j];
  for (int i = 0; i < LM_N * LM_E; i++) {
    const int8_t *w = &lm_w1[i * LM_H];
    float xi = x[i] * LM_S_W1;
    for (int j = 0; j < LM_H; j++) h[j] += xi * (float)w[j];
  }
  for (int j = 0; j < LM_H; j++) h[j] = lm_softsign(h[j]);
  for (int v = 0; v < LM_V; v++) logits[v] = lm_b2[v];
  for (int j = 0; j < LM_H; j++) {
    const int8_t *w = &lm_w2[j * LM_V];
    float hj = h[j] * LM_S_W2;
    for (int v = 0; v < LM_V; v++) logits[v] += hj * (float)w[v];
  }
}

/* Tire le symbole suivant. temperature > 0 ; top_k limite le choix (0 = tous). */
static int lm_sample(lm_state_t *s, float temperature, int top_k) {
  float logits[LM_V], p[LM_V];
  lm_logits(s, logits);

  float thresh = -1e30f;
  if (top_k > 0 && top_k < LM_V) {
    /* seuil du k-ième meilleur logit (tri partiel simple) */
    float tmp[LM_V];
    for (int v = 0; v < LM_V; v++) tmp[v] = logits[v];
    for (int a = 0; a < top_k; a++) {
      int best = a;
      for (int b = a + 1; b < LM_V; b++) if (tmp[b] > tmp[best]) best = b;
      float t = tmp[a]; tmp[a] = tmp[best]; tmp[best] = t;
    }
    thresh = tmp[top_k - 1];
  }

  float mx = -1e30f;
  for (int v = 0; v < LM_V; v++) if (logits[v] > mx) mx = logits[v];
  float sum = 0.0f;
  for (int v = 0; v < LM_V; v++) {
    p[v] = (logits[v] >= thresh) ? lm_exp_neg((logits[v] - mx) / temperature) : 0.0f;
    sum += p[v];
  }
  float r = (float)(lm_rand(s) >> 8) * (1.0f / 16777216.0f) * sum;
  int pick = LM_V - 1;
  for (int v = 0; v < LM_V; v++) {
    r -= p[v];
    if (r <= 0.0f) { pick = v; break; }
  }
  /* décale le contexte */
  for (int k = 0; k < LM_N - 1; k++) s->ctx[k] = s->ctx[k + 1];
  s->ctx[LM_N - 1] = (uint8_t)pick;
  return pick;
}

/* Alimente le contexte avec un caractère (pour imposer un début de phrase). */
static void lm_feed(lm_state_t *s, char c) {
  int idx = 0;
  const char *a = LM_ALPHABET;
  if (c >= 'A' && c <= 'Z') c = (char)(c - 'A' + 'a');
  for (int i = 0; i < LM_V; i++) if (a[i] == c) { idx = i; break; }
  for (int k = 0; k < LM_N - 1; k++) s->ctx[k] = s->ctx[k + 1];
  s->ctx[LM_N - 1] = (uint8_t)idx;
}

static void lm_init(lm_state_t *s, uint32_t seed) {
  for (int k = 0; k < LM_N; k++) s->ctx[k] = 0;
  s->rng = seed ? seed : 0x9E3779B9u;
}

#endif
