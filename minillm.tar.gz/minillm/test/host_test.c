#include <stdio.h>
#include "../src/lm.h"
int main(void) {
  float temps[] = {0.5f, 0.8f, 1.1f};
  const char *seed = "Un nombre ";
  for (int t = 0; t < 3; t++) {
    lm_state_t s; lm_init(&s, 777 + t);
    for (const char *p = seed; *p; p++) lm_feed(&s, *p);
    printf("T=%.1f : %s", temps[t], seed);
    for (int i = 0; i < 200; i++) putchar(LM_ALPHABET[lm_sample(&s, temps[t], 8)]);
    printf("\n\n");
  }
  /* logits pour comparer avec numpy */
  lm_state_t s; lm_init(&s, 1);
  for (const char *p = "un nombre "; *p; p++) lm_feed(&s, *p);
  float lg[LM_V]; lm_logits(&s, lg);
  int best = 0; for (int v = 1; v < LM_V; v++) if (lg[v] > lg[best]) best = v;
  printf("C: lettre la plus probable apres 'e nombre ' = '%c' logit=%.4f\n", LM_ALPHABET[best], lg[best]);
  /* test exp */
  printf("exp(-1)=%.5f (attendu 0.36788)  exp(-5)=%.6f (attendu 0.006738)\n", lm_exp_neg(-1.0f), lm_exp_neg(-5.0f));
  return 0;
}
