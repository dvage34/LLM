/* Faux eadk.h pour compiler/valider main.c sur PC (la vraie version vient du SDK NumWorks). */
#ifndef EADK_STUB_H
#define EADK_STUB_H
#include <stdint.h>
#include <stdbool.h>
typedef uint16_t eadk_color_t;
typedef struct { uint16_t x, y, width, height; } eadk_rect_t;
typedef struct { uint16_t x, y; } eadk_point_t;
typedef uint64_t eadk_keyboard_state_t;
typedef enum { eadk_key_left, eadk_key_up, eadk_key_down, eadk_key_right, eadk_key_ok, eadk_key_back } eadk_key_t;
static const eadk_rect_t eadk_screen_rect = {0, 0, 320, 240};
static inline void eadk_display_push_rect_uniform(eadk_rect_t r, eadk_color_t c) { (void)r; (void)c; }
static inline void eadk_display_draw_string(const char *s, eadk_point_t p, bool l, eadk_color_t f, eadk_color_t b) { (void)s; (void)p; (void)l; (void)f; (void)b; }
static inline eadk_keyboard_state_t eadk_keyboard_scan(void) { return 0; }
static inline bool eadk_keyboard_key_down(eadk_keyboard_state_t s, eadk_key_t k) { return (s >> k) & 1; }
static inline void eadk_timing_msleep(uint32_t ms) { (void)ms; }
static inline uint32_t eadk_random(void) { return 42; }
#endif
